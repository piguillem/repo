import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class GradeCalculator {

    public static void main(String[] args) throws IOException

    {
        String configFile="gradeconfig.txt";
        String courseName= "CMSC203 Computer Science I";
        
        int numGradedofCategories=3;
        int totalWeight=0;
        String defaultUsed="No";

        String[] categoryName = {"Projects", "Quizzes", "Exams"};
        int[] categoryWeight = {40, 30, 30};
        




        // 1: Configuration File

        try(Scanner inputFile=new Scanner(new File(configFile)))
        {   
            courseName=inputFile.nextLine();
            numGradedofCategories=inputFile.nextInt();

            categoryWeight=new int[numGradedofCategories];
            categoryName=new String[numGradedofCategories];
            
            for (int i=0;i<numGradedofCategories; i++) {
                
                categoryName[i]=inputFile.next();
                categoryWeight[i]=inputFile.nextInt();
                totalWeight+=categoryWeight[i];
                
            }

            

            if (!(totalWeight==100))
            {
                System.out.println("the config file is missing or invalid, therefore, this program will use default config");

                numGradedofCategories = 3;
                categoryName = new String[]{"Projects", "Quizzes", "Exams"};
                categoryWeight = new int[]{40, 30, 30};
                defaultUsed="yes";

            }

            

        }
        catch( FileNotFoundException | NoSuchElementException e)

        {   
            System.out.print("Config file invalid or missing, using default config");
            
            numGradedofCategories = 3;
            categoryName = new String[]{"Projects", "Quizzes", "Exams"};
            categoryWeight = new int[]{40, 30, 30};
            defaultUsed="yes";
            

        }
    



         // 2: Student Scores Input

    String firstName="";
    String lastName="";
    String studentscoreFile="Grades_input.txt";
    String[] categoryNamevalidation=new String[numGradedofCategories];

    double[] sum=new double[numGradedofCategories];
    double[] ave=new double[numGradedofCategories];


    
    try(Scanner inputFileScores=new Scanner(new File(studentscoreFile)))
    {
        firstName=inputFileScores.nextLine();
        lastName=inputFileScores.nextLine();
       
        



        for(int i=0;i<numGradedofCategories;i++)
        {   
            categoryNamevalidation[i]=inputFileScores.next();
            

            if (categoryNamevalidation[i].equals(categoryName[i])) {
                int n=inputFileScores.nextInt();
                sum[i]=0;
                
                for(int w=0;w<n;w++)
                {
                    sum[i]+=inputFileScores.nextDouble();
                }

                if(n>0)
                {
                    ave[i]=sum[i]/n;

                }
                
                
            }
            else
            {
            int ecase=inputFileScores.nextInt();
            for (int x=0;x<ecase;x++)
            {
                inputFileScores.nextDouble();
            }
                System.out.println("error "+categoryNamevalidation[i]+" does not matches the category of the config file, thus skipped");
                 }   
            

        }




    }
        catch (FileNotFoundException | NoSuchElementException e)
        {
    System.out.println("Scores file missing or invalid.");
        }



    

    // 3: calculation logic
    double finalScore=0;
    String finalGrade="";

    for(int i=0;i<numGradedofCategories;i++)
    {

        finalScore+=ave[i]*categoryWeight[i]/100.0;

    }
    
    if (finalScore>=90 && finalScore<101) {
       
        finalGrade="A";
    }
    else if (finalScore>=80) {
        finalGrade="B";
        
    }
    else if (finalScore>=70) {
        finalGrade="C";
    }
    else if (finalScore>=60) {
        finalGrade="D";
        
    }
    else if (finalScore>=0 && finalScore<60) {
        finalGrade="F";
    }

    // 4: Keyboard input and Input Validation

    char charselection;

    System.out.print("Apply +/- grading (Y/N):");
    Scanner inputcharselec=new Scanner(System.in);

    String input=inputcharselec.nextLine();
    
    charselection = input.isEmpty() ? ' ' : Character.toUpperCase(input.charAt(0));

   while (! (Character.toUpperCase(charselection) =='Y') && ! (Character.toUpperCase(charselection) =='N')) {
    System.out.print("Apply +/- grading (Y/N):");
     

     input=inputcharselec.nextLine();
    
     charselection = input.isEmpty() ? ' ' : Character.toUpperCase(input.charAt(0));
    
   }  
    
        
    
        
    

    if (Character.toUpperCase(charselection)=='Y'  )
         {

        double temp=finalScore/10;
        double decimal=temp-(int)temp;

          if (finalScore == 100) {
        finalGrade = finalGrade + "+";
    }
        
        

        else if (decimal>=0.7) {

            finalGrade=finalGrade + "+";

        }

         else if (decimal<=0.3) {

            finalGrade=finalGrade+"-";
            
        }

            
        }


        
    //6: Output requirements

    System.out.println("Course Name:"+courseName);
    System.out.println("Student's Name:"+firstName+" "+lastName);
    
    for(int i=0;i<numGradedofCategories;i++)
    {
        System.out.println("Category:"+categoryName[i]);
        System.out.println("average:"+ave[i]);
        System.out.println("weight:"+categoryWeight[i]);
        

    }

    System.out.printf("Final Score:%.2f",finalScore);
    System.out.println();
    

    System.out.println("Final Grade:" + finalGrade);

    System.out.println("config used:"+defaultUsed);




    PrintWriter outputFile= new PrintWriter("grades_report.txt");
        
    
    outputFile.println("Course Name:"+courseName);
    outputFile.println("Student's Name:"+firstName+" "+lastName);
    
    for(int i=0;i<numGradedofCategories;i++)
    {
        outputFile.println("Category:"+categoryName[i]);
        outputFile.println("average:"+ave[i]);
        outputFile.println("weight:"+categoryWeight[i]);
        

    }

    outputFile.printf("Final Score:%.2f",finalScore);
    outputFile.println();

    outputFile.println("Final Grade:"+finalGrade);

    outputFile.println("config used:"+defaultUsed);
        
    
    }

    

    





}